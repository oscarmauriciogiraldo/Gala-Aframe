export const environment = {
  production: true,
  defaultauth: 'firebase',
  firebaseConfig: {
    apiKey: "AIzaSyClHICgyHwJB0af5Bs3VJNZvkGbaM5KDKI",
    authDomain: "galavirtual.firebaseapp.com",
    databaseURL: "https://galavirtual.firebaseio.com",
    projectId: "galavirtual",
    storageBucket: "galavirtual.appspot.com",
    messagingSenderId: "78682972282",
    appId: "1:78682972282:web:00a39d90c124eb8aec9bc3",
    measurementId: "G-1YTHFGQ6JH"
  }
};

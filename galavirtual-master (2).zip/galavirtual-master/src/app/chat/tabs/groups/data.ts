const groups = [
    {
        id: 1, name: 'chat.tabs.groups.list.general'
    }, {
        id: 2, name: 'chat.tabs.groups.list.reporting',
        unread: '+23'
    }, {
        id: 3, name: 'chat.tabs.groups.list.designers'
    }, {
        id: 4, name: 'chat.tabs.groups.list.developer',
        unread: 'New'
    }, {
        id: 5, name: 'chat.tabs.groups.list.projectalpha'
    }, {
        id: 6, name: 'chat.tabs.groups.list.snacks',
    }
];

export { groups };


export interface Groups {
    id: number;
    name: string;
    unread?: string;
}
